const mysql = require("mysql");

let connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "admin",
  database: "react_node"
});

module.exports = {
    connectdb,
    disconnectdb,
    runquery
};

function connectdb() {
  connection.connect(function(err) {
    if (err) {
      return console.error("error: " + err.message);
    }
    console.log("Connected to the MySQL server.");
  });
  return connection;
}

function runquery(querys) {
  return connection.query(querys, function(err, results, fields) {
    if (err) {
      console.log(err.message);
    }
    console.log(`The results ${JSON.stringify(results)}`);
  })
}

function disconnectdb() {
  connection.end(function(err) {
    if (err) {
      return console.log("error:" + err.message);
    }
    console.log("Database connection is closing.");
    connection.destroy();
    console.log("Database connection is closed.");
  });
}
