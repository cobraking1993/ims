﻿require("rootpath")();
const express = require("express");
const app = express();
const cors = require("cors");
const bodyParser = require("body-parser");
const basicAuth = require("_helpers/basic-auth");
const errorHandler = require("_helpers/error-handler");
const multer = require("multer");
const userService = require("users/user.service");
var xlstojson = require("xls-to-json-lc");
var xlsxtojson = require("xlsx-to-json-lc");
//const userController = require('users/user.controller');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


// api routes
app.use("/users", require("./users/users.controller"));

app.post("/authenticate", function(req, res, next) {
    userService.corfix(req, res);
    userService.authenticate(req.body)
        .then(user => user ? res.json(user) : res.status(400).json({ message: 'Username or password is incorrect' }))
        .catch(err => next(err));
});

const showexcel = userService.showexcel;
app.post("/showexcel", function(req, res) {
  filedata = userService.showexcel(req, res);
  userService.corfix(req, res);
  console.log("THe FIle content : :LOG :: ", filedata);
  return res.status(200).send(filedata);
});

app.get("/showtables", function(req, res) {
  tables = userService.showtable(req, res);
  userService.corfix(req, res);
  console.log("THe FIle content : :LOG :: ", filedata);
  return res.status(200).send(tables);
});

//create storage to store uploaded files
const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, "public");
  },
  filename: function(req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  }
});

const importexcel = multer({
  storage: storage
  //   fileFilter: function(req, file, callback) {
  //     //file filter
  //     if (["xls", "xlsx"].indexOf(file.originalname.split(".")[file.originalname.split(".").length - 1]) === -1 ) {
  //       return callback(new Error("Wrong extension type"));
  //     }
  //     callback(null, true);
  //   }
}).single("file");

app.post("/importexcel", function(req, res) {
  //var exceltojson;
  importexcel(req, res, function(err) {
    if (err instanceof multer.MulterError) {
      return res.status(500).json(err);
    } else if (err) {
      return res.status(500).json(err);
    }
    userService.corfix(req, res);
    return res.status(200).send(req.file);
  })

});

app.use(cors());
// use basic HTTP auth to secure the api
app.use(basicAuth);

// global error handler
app.use(errorHandler);

// start server
const port = process.env.NODE_ENV === "production" ? 80 : 4000;
const server = app.listen(port, function() {
  console.log("Server listening on port " + port);
});
