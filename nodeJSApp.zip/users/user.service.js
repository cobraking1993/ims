﻿
// users hardcoded for simplicity, store in a db for production applications
const users = [
  {
    id: 1,
    username: "test",
    password: "test",
    firstName: "Test",
    lastName: "User"
  }
];
const readXlsxFile = require("read-excel-file/node");
const db = require("database.js");

module.exports = {
  authenticate,
  getAll,
  showexcel,
  corfix
};

async function corfix(req, res) {
  res.setHeader(
    "Access-Control-Allow-Origin",
    req.header("origin") ||
      req.header("x-forwarded-host") ||
      req.header("referer") ||
      req.header("host")
  );
}

async function authenticate({ username, password }) {
  console.log("AUthenticating USER")
  const user = users.find(
    u => u.username === username && u.password === password
  );
  if (user) {
    const { password, ...userWithoutPassword } = user;
    return userWithoutPassword;
  }
}

async function getAll() {
  return users.map(u => {
    const { password, ...userWithoutPassword } = u;
    return userWithoutPassword;
  });
}

function showexcel(req, res) {
  var tablename = JSON.stringify(req.body.filename)
    .replace(/.xlsx|.xls/gi, "")
    .replace(/"/gi, "")
    .replace(/-/, "_");
  readXlsxFile(req.body.path).then(rows => {
    rowheaders = JSON.stringify(
      rows
        .shift()
        .join("|")
        .toLowerCase()
        .split("|")
    )
      .split(" ")
      .join("_");
    rowheaders = rowheaders.split("/").join("_");
    rowheaders = rowheaders.split("'").join("_");
    dbcolumndef = rowheaders + ' TEXT"';
    dbcolumndef = rowheaders.replace(/",/gi, ' TEXT", ');
    dbcolumndef = dbcolumndef.replace(/\[/gi, "").replace(/\]/gi, "");
    dbcolumndef = dbcolumndef.replace(/usage/, "_usage").replace(/"/gi, "");

    db.connectdb();

    let sql = `CREATE TABLE IF NOT EXISTS ${tablename} (id INT AUTO_INCREMENT PRIMARY KEY, ${dbcolumndef} TEXT);`;
    console.log(`THE SQL QUERY : ${sql} : ----`);
    db.runquery(sql);

    rows.forEach(function(value) {
      var ipdata = value.map(function(val) {
        return `${JSON.stringify(val).replace(/,/gi, "#")}`;
      });

      let sql = `insert into ${tablename} (${rowheaders
        .replace(/\[/gi, "")
        .replace(/\]/gi, "")
        .replace(/\"/gi, "")
        .replace(/usage/, "_usage")
        .replace(/"/gi, "")})
      values (
            ${JSON.stringify(ipdata)
              .replace(/\[/gi, "")
              .replace(/\]/gi, "")}); `;

      db.runquery(sql);
    });
  });
  console.log("FILE DATA : LOG : ", filedata);

  db.disconnectdb();
  return filedata;
}