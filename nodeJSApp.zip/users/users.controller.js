﻿const express = require('express');
const router = express.Router();
const userService = require('./user.service');
const readXlsxFile = require('read-excel-file/node');

// routes
router.post('/authenticate', authenticate);
router.get('/', getAll);
router.post('/importexcel', importExcel);
router.post('/showexcel', showExcel);
router.post('/showexcel', showTable);

module.exports = router;

function authenticate(req, res, next) {
    userService.authenticate(req.body)
        .then(user => user ? res.json(user) : res.status(400).json({ message: 'Username or password is incorrect' }))
        .catch(err => next(err));
}

function getAll(req, res, next) {
    userService.getAll()
        .then(users => res.json(users))
        .catch(err => next(err));
}

async function importExcel(req, res, next) {
    console.log('NodeJS log : importExcel : ', req)
    // File path.
}

async function showExcel(req, res, next) {
    console.log("NODEJS Controller Log : showExcel : -------------------------------------------------- ")
    userService.showexcel(req)
}

async function showTable(req, res, next) {
    console.log("NODEJS Controller Log : Show Tables : -------------------------------------------------- ")
    userService.getAlltable(req)
}