# node-basic-authentication-api

NodeJS Basic HTTP Authentication API

For documentation and instructions check out http://jasonwatmore.com/post/2018/09/24/nodejs-basic-authentication-tutorial-with-example-api