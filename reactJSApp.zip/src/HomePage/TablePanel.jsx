import React from 'react';

function TablePanel(props) {
    return (
        <div className="col-sm-12 tablePanel">
            <br /><br />
            <div className="card dashboardRow">
                <div className="card-body">
                    <h4 className="card-title">{props.title}</h4>
                    {props.children}
                </div>
            </div>
        </div>
    );
}

export default TablePanel;