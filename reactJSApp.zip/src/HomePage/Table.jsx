import React from 'react';
import TablePanel from './TablePanel';

const TestTable = ({ tableData }) => {
	return (
		<TablePanel title="Excel Sheet Data">
			<table className="table">
				<thead>
					<tr>
						<th>col 1</th>
						<th>col 2</th>
						<th>col 3</th>
						<th>col 4</th>
					</tr>
				</thead>
				<tbody>
					{/*{tableData.map((keys, data) =>
						(<tr key={data.id}>
							<td>{data.keys}</td>
						</tr>))}*/}
				</tbody>
			</table>
		</TablePanel>

	);
}

export default TestTable;