import React from 'react';
import { Link } from 'react-router-dom';
import { userService } from '../_services';
import TestTable from './Table';
import './Home.css'

class HomePage extends React.Component {
    constructor(props) {
        super(props);
        
        this.state = {
            user: {},
            users: [],
            selectedFile: null,
            tableData: {}
        }
    }

    componentDidMount() {
        this.setState({
            user: JSON.parse(localStorage.getItem('user')),
            users: { loading: true },
            tableData: {}
        });
        userService.getAll().then(users => this.setState({ users }));
        //userService.showTable().then(tableData => this.setState({ tables }));
    }

    componentDidUpdate() {
        console.log("Component is updated")
    }

    onChangeHandler = event => {
        this.setState({
            selectedFile: event.target.files[0],
            loaded: 0,
        }, console.log(event.target.files[0]))

    }

    fileImportHandler = (e) => {
        e.preventDefault();
        userService.importExcel(this.state.selectedFile)
            .then((response) => response.json())
            .then((responseJson) => {
                userService.showExcel(responseJson);
            })
    }

    render() {
        const { user } = this.state;
        var divStyle = {
            backgroundColor: 'white',
            width: '100%',
            WebkitTransition: 'all', // note the capital 'W' here
            msTransition: 'all' // 'ms' is the only lowercase vendor prefix
        };

        var importButtonStyle = {
            width: '15%'
        };

        return (
            <div style={divStyle}>
                <ul className='nav-bar'>
                    <li>
                        <Link className="home-page-link" to="/">Home</Link>
                    </li>

                    <li>
                        <Link className='logout-link' to="/login">Logout</Link>
                    </li>
                </ul>
                <div className="col-md-6 col-md-offset-3">
                    <h1>Hi {user.firstName}!</h1>
                    <p>You're logged in with React + NodeJS Application!!</p>
                    <br /><br />
                    <label> Import Excel File </label>
                    <input type="file" name="file" onChange={this.onChangeHandler} /> <br />
                    <button type="button" className="btn btn-success btn-block" style={importButtonStyle} onClick={this.fileImportHandler}>Import</button>
                </div>
                {/*<TestTable tableData={this.state} />*/}
            </div>
        );
    }
}

export { HomePage };