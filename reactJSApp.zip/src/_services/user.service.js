import config from 'config';
import { authHeader } from '../_helpers';
import { authHeader1 } from '../_helpers';

export const userService = {
    login,
    logout,
    getAll,
    showExcel,
    showTable,
    importExcel
};

function login(username, password) {
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    };
    return fetch(`${config.apiUrl}/authenticate`, requestOptions)
        .then(handleResponse)
        .then(user => {
            // login successful if there's a user in the response
            if (user) {
                // store user details and basic auth credentials in local storage 
                // to keep user logged in between page refreshes
                user.authdata = window.btoa(username + ':' + password);
                localStorage.setItem('user', JSON.stringify(user));
            }
            return user;
        });
}

function logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('user');
}

function getAll() {
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };
    return fetch(`${config.apiUrl}/users`, requestOptions).then(handleResponse);
}

function showExcel(file) {
    const data = new FormData()
    data.append('file', JSON.stringify(file))

    const requestOptions = {
        method: 'POST',
        headers: authHeader1(),
        body: JSON.stringify(file)
    };
    return fetch(`${config.apiUrl}/showexcel`, requestOptions)
}

function showTable() {
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };
    return fetch(`${config.apiUrl}/showtables`, requestOptions)
}

function importExcel(file) {
    const data = new FormData()
    data.append('file', file)

    const requestOptions = {
        method: 'POST',
        headers: authHeader(),
        body: data
    };
    return fetch(`${config.apiUrl}/importexcel`, requestOptions)
}

function handleResponse(response) {
    return response.text().then(text => {
        const data = text && JSON.parse(text);
        if (!response.ok) {
            if (response.status === 401) {
                // auto logout if 401 response returned from api
                logout();
                location.reload(true);
            }

            const error = (data && data.message) || response.statusText;
            return Promise.reject(error);
        }

        return data;
    });
}