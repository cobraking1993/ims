import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';

import { PrivateRoute } from '../_components';
import { HomePage } from '../HomePage';
import { LoginPage } from '../LoginPage';


class App extends React.Component {
    render() {
        return (
            // <div className="jumbotron">
            <div>
                {/*<div className="container">*/}
                <div>
                    <div className="col-sm-10 col-sm-offset-1">
                        <Router>
                            <div>
                                <PrivateRoute exact path="/" component={HomePage} />
                                <Route path="/login" component={LoginPage} />
                            </div>
                        </Router>
                    </div>
                </div>
            </div>
            //</div>
        );
    }
}

export { App }; 